<?php include("listing-connect.php"); ?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../../../favicon.ico">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">

    <title> Job Listings </title>

    <!-- Bootstrap core CSS -->
    <link href="../../dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="offcanvas.css" rel="stylesheet">
  </head>

  <body class="bg-light">
  <body class="bg-light">
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample08" aria-controls="navbarsExample08" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse justify-content-md-center" id="navbarsExample08">
        <ul class="navbar-nav">
          <li class="nav-item active">
            <a class="nav-link" href="provider.php"> Return Dashboard </a>
          </li>

					<li class="nav-item active">
						<a class="nav-link" href="listing-edit-provider.php"> | &nbsp; &nbsp; Create & Edit Job Listings</a>
					</li>
        </ul>
      </div>
    </nav>
    <main role="main" class="container">

      <div class="my-3 p-3 bg-white rounded shadow-sm">
        <h5 class="border-bottom border-gray pb-2 mb-0"> <em> Job Listings </em> </h5>
      </div>
    </main>
        <?php
          $x = 0;

          $id="";
          $title="";
          $description="";
          $salary="";
          $location="";
          $time="";
          $sql = "SELECT * FROM listing";
      
          if($result=mysqli_query($conn,$sql))
          {
            while($row=mysqli_fetch_assoc($result)){
        

              $id = $row['id'];
              $title = $row['title'];
              $description = $row['description'];
              $salary = $row['salary'];
              $location = $row['location'];
              $time = $row['time'];

        ?>
              <main role="main" class="container">
                <form method="get">
                  <div class="my-3 p-3 bg-white rounded shadow-sm">
                    <div class="media text-muted pt-3">
                      <img data-src="holder.js/32x32?theme=thumb&bg=007bff&fg=007bff&size=1" alt="" class="mr-2 rounded">
                      <p class="media-body pb-3 mb-0 small lh-125 border-bottom border-gray">
                        <strong class="d-block text-gray-dark"> Title             : </strong> <?php echo $title ?> <br>
                        <strong class="d-block text-gray-dark"> Description       : </strong> <?php echo $description ?> <br>
                        <strong class="d-block text-gray-dark"> Expected Salary   : </strong> <?php echo $salary ?> <br>
							          <strong class="d-block text-gray-dark"> Location          : </strong> <?php echo $location ?> <br>
                        <strong class="d-block text-gray-dark"> ID                : </strong> <?php echo $id ?><br>
                        <strong class="d-block text-gray-dark"> Date              : </strong> <?php echo $time ?> <br>
                      </p>
                      </div>
                    </div> 
                  </form>
                </main>
                <?php

			    $x++;
            }
          }
         
	?>
      </div>
    </main>
  </body>
</html>
