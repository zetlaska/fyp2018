<?php

	$host = "localhost";
	$user = "root";
	$dbpassword = "";
	$database = "futureplan";

	$id = "";
	$title = "";
	$description = "";
	$salary = "";
	$location = "";
	$time = "";
	$provID = "";
	$provname = "";

	mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

	try{
		$connect = mysqli_connect($host, $user, $dbpassword, $database);
	}catch(Exception $ex){
		echo 'Error';
	}

	function getPosts(){
		$posts = array();
		$posts[0] = $_POST['id'];
		$posts[1] = $_POST['title'];
		$posts[2] = $_POST['description'];
		$posts[3] = $_POST['salary'];
		$posts[4] = $_POST['location'];
		$posts[5] = $_POST['provID'];
		$posts[6] = $_POST['provname'];


		return $posts;
	}

	//Search Function
	if(isset($_POST['search'])){
		$data = getPosts();

		$search_Query = "SELECT * FROM listing WHERE id = $data[0]";

		$search_Result = mysqli_query($connect, $search_Query);

		if($search_Result){
			if(mysqli_num_rows($search_Result)){
				while($row = mysqli_fetch_array($search_Result)){
					$id = $row['id'];
					$title = $row['title'];
					$description = $row['description'];
					$salary = $row['salary'];
					$location = $row['location'];
					$provID = $row['provID'];
					$provname = $row['provname'];
				}
			}else{
				echo 'No data for this id';
			}
		}else{
			echo 'Result Error';
		}
	}

	//Insert Function
	if(isset($_POST['insert'])){
		$data = getPosts();
		$insert_Query = "INSERT INTO `listing`(`title`, `description`, `salary`, `location`, `provID`, `provname`) VALUES ('$data[1]','$data[2]','$data[3]', '$data[4]', '$data[5]', '$data[6]')";
	
		try{
			$insert_Result = mysqli_query($connect, $insert_Query);

			if($insert_Result){
				if(mysqli_affected_rows($connect) > 0){
					echo 'Data Inserted';
				}else{
					echo 'Data Not Inserted';
				}
			}
		}catch(Exception $ex){
			echo 'Error Insert'.$ex->getMessage();
		}
	}

	//Delete Function
	if(isset($_POST['delete'])){
		$data = getPosts();
		$delete_Query = "DELETE FROM `listing` WHERE `id` = '$data[0]'";

		try{
			$delete_Result = mysqli_query($connect, $delete_Query);

			if($delete_Result){
				if(mysqli_affected_rows($connect) > 0){
					echo 'Data Deleted';
				}else{
					echo 'Data Not Deleted';
				}
			}
		}catch(Exception $ex){
			echo 'Error in Deletion'.$ex->getMessage();
		}
	}

	//Update Function
	if(isset($_POST['update'])){
		$data = getPosts();
		$update_Query = "UPDATE `listing` SET `title`='$data[1]',`description`='$data[2]',`salary`='$data[3]',`location`='$data[4]',`provID`='$data[5]',`provname`='$data[6]'  WHERE `id` = '$data[0]'";

		try{
			$update_Result = mysqli_query($connect, $update_Query);

			if($update_Result){
				if(mysqli_affected_rows($connect) > 0){
					echo 'Data Updated';
				}else{
					echo 'Data Not Updated';
				}
			}
		}catch(Exception $ex){
			echo 'Error in Updating Data'.$ex->getMessage();
		}
	}

?>

<!doctype html>
<html>
	<head>
		<title> Edit Job Listing </title>
		<html lang="en">
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta name="description" content="">
		<meta name="author" content="">
		<link rel="icon" href="../../../../favicon.ico">
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
		<!-- Bootstrap core CSS -->
		<link href="../../dist/css/bootstrap.min.css" rel="stylesheet">

		<!-- Custom styles for this template -->
		<link href="offcanvas.css" rel="stylesheet">
	</head>

 	<body class="bg-light">
    	<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample08" aria-controls="navbarsExample08" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
			</button>

			<div class="collapse navbar-collapse justify-content-md-center" id="navbarsExample08">
				<ul class="navbar-nav">
					<li class="nav-item active">
						<a class="nav-link" href="admin.php"> Return to Dashboard </a>
					</li>
				</ul>
			</div>
    	</nav>

		<main role="main" class="container">

			<div class="my-3 p-3 bg-white rounded shadow-sm">
  			<h5 class="border-bottom border-gray pb-2 mb-0"> <em> Control Form </em> </h5>
  			<form method = "post" action = "listing-edit-admin.php">
						<div class="mb-3">
							<label for="id"> Job Listing ID </label>
							<input type="number" class="form-control" id="id" name = "id" value = "<?php echo $id ?>">
							<div class="invalid-feedback">
								Enter ID
							</div>
						</div>

						<div class="mb-3">
							<label for="title"> Job Listing Title </label>
							<input type="text" class="form-control" id="title" name = "title" value = "<?php echo $title ?>">
							<div class="invalid-feedback">
								Enter Title
							</div>
						</div>

						<div class="mb-3">
							<label for="description"> Description </label>
							<textarea class="form-control" id="description" name = "description" value = ""><?php echo $description ?></textarea>
							<div class="invalid-feedback">
								Enter Description.
							</div>
						</div>

						<div class="mb-3">
							<label for=""> Salary </label>
							<input type="text" class="form-control" id="salary" name = "salary" value = "<?php echo $salary ?>">
							<div class="invalid-feedback">
								Enter a Valid Salary
							</div>
						</div>

						<div class="mb-3">
							<label for=""> Location </label>
							<input type="text" class="form-control" id="location" name = "location" value = "<?php echo $location ?>">
							<div class="invalid-feedback">
								Please enter a valid location.
							</div>

						<div class="mb-3">
							<label for=""> Job Provider ID </label>
							<input type="text" class="form-control" id="provID" name = "provID" value = "<?php echo $provID ?>">
							<div class="invalid-feedback">
								Please enter Company ID.
							</div>							
						</div>						

						<div class="mb-3">
							<label for=""> Job Provider Name </label>
							<input type="text" class="form-control" id="prov" name = "provname" value = "<?php echo $provname ?>">
							<div class="invalid-feedback">
								Please enter Company Name.
							</div>

						<div class = "spacing"/>
						<div class = "spacing"/>

						<div>
							<a href = "admin.php" class ="btn btn-sm btn-outline-secondary" type="submit" name = "update"> Return to Admin Home Page </a>
							<a class="btn btn-sm btn-outline-secondary" href = "listing-create-admin.php"> Add </a>
							<input class="btn btn-sm btn-outline-secondary" type="submit" name = "update" value = "Update">
							<input class="btn btn-sm btn-outline-secondary" type="submit" name = "delete" value = "Delete">
							<input class="btn btn-sm btn-outline-secondary" type="submit" name = "search" value = "Search">

						</div>
					</form>
				</div>
			</div>
	</body>
</html>
