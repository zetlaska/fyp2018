<?php
	session_start();

	if(isset($_POST["username"])) {
		include 'connect.php';

		$userID = $_POST["id"];
		$username = $_POST["username"];
		$email = $_POST["email"];
		$phone = $_POST["contact"];

		$message = "";

		if ($username == "") {

			$message = "Name must be filled!";

		} else if ($email == "") {

			$message = "Email must be filled!";
		}
		else if ($phone == "") {

			$message = "Phone number must be filled!";
		}
		else {

			$connection->query("UPDATE user SET username='".$username."', email='".$email."' WHERE userID=".$userID);

			$message = "Successfully updated ";

		}

		$_SESSION["message"] = $message;

		header("Location: updateUser1.php?id=".$userID);
		exit();

	}

	header("Location: ../pool/adminChoice.php");
	exit();
?>
