<?php

	session_start();

	// initializing variables
	$id       = "";
	$username = "";
	$email    = "";
	$contact  = "";
	$link     = "";
	$errors   = array();

	// connect to the database
	$db = mysqli_connect('localhost', 'root', '', 'futureplan');

	// REGISTER SEEKER
	if (isset($_POST['reg_user'])) {

		// receive all input values from the form
		$username = mysqli_real_escape_string($db, $_POST['username']);
		$email = mysqli_real_escape_string($db, $_POST['email']);
		$contact = mysqli_real_escape_string($db, $_POST['contact']);
		$password_1 = mysqli_real_escape_string($db, $_POST['password_1']);
		$password_2 = mysqli_real_escape_string($db, $_POST['password_2']);


		// form validation: ensure that the form is correctly filled ...
		// by adding (array_push()) corresponding error unto $errors array
		if (empty($username)) {
			array_push($errors, "Username is required");
		}

		if (empty($email)) {
			array_push($errors, "Email is required");
		}

		if (empty($contact)) {
			array_push($errors, "Contact number is required");
		}

		if (empty($password_1)) {
			array_push($errors, "Password is required");
		}

		if ($password_1 != $password_2) {
			array_push($errors, "The two passwords do not match");
		}

		// first check the database to make sure
		// a user does not already exist with the same username and/or email
		$user_check_query = "SELECT * FROM jobseeker WHERE username = '$username' OR email = '$email' LIMIT 1";
		$result = mysqli_query($db, $user_check_query);
		$user = mysqli_fetch_assoc($result);

		if ($user) { // if user exists
			if ($user['username'] === $username) {
				array_push($errors, "Username already exists");
			}

			if ($user['email'] === $email) {
				array_push($errors, "email already exists");
			}
		}

		// Finally, register user if there are no errors in the form
		if (count($errors) == 0) {
			$password = md5($password_1);//encrypt the password before saving in the database

			$query = "INSERT INTO
									jobseeker (username, password, email, contact)
								VALUES
									('$username', '$password', '$email', '$contact')";

			mysqli_query($db, $query);
			$_SESSION['username'] = $username;
			$_SESSION['id'] = $db->insert_id;
			$_SESSION['email'] = $email;
			$_SESSION['contact'] = $contact;
			$_SESSION['success']  = "You are now logged in";
			header('location: jobseeker.php');
		}
	}

	// LOGIN SEEKER
	if (isset($_POST['login_user'])) {
		$username = mysqli_real_escape_string($db, $_POST['username']);
		$password = mysqli_real_escape_string($db, $_POST['password']);

		if (empty($username)) {
			array_push($errors, "Username is required");
		}

		if (empty($password)) {
			array_push($errors, "Password is required");
		}

		if (count($errors) == 0) {

			$password = md5($password);
			$query = "SELECT * FROM jobseeker WHERE username='$username' AND password='$password'";
			$results = mysqli_query($db, $query);

			if (mysqli_num_rows($results) == 1) {
				$_SESSION['username'] = $username;
				$_SESSION['id'] = $db->insert_id;

				$_SESSION['success']  = "You are now logged in";
				header('location: jobseeker.php');
			}else {
				array_push($errors, "Wrong username/password combination");
			}
		}
	}

	// LOGIN ADMIN
	if (isset($_POST['login_admin'])) {
		$admin_username = mysqli_real_escape_string($db, $_POST['admin_username']);
		$admin_password = mysqli_real_escape_string($db, $_POST['admin_password']);

		if (empty($admin_username)) {
			array_push($errors, "Username is required");
		}

		if (empty($admin_password)) {
			array_push($errors, "Password is required");
		}

		if (count($errors) == 0) {

			$query = "SELECT * FROM `admin` WHERE username = '$admin_username' AND password = '$admin_password'";
			$results = mysqli_query($db, $query);
			if (mysqli_num_rows($results) == True) {
				$_SESSION['admin_username'] = $admin_username;
				$_SESSION['success'] = "You are now logged in";
				header('location: admin.php');
			}else {
				array_push($errors, "Wrong username/password combination");
			}
		}
	}

	// REGISTER PROVIDER
	if (isset($_POST['reg_provider'])) {

		// receive all input values from the form
		$username = mysqli_real_escape_string($db, $_POST['username']);
		$email = mysqli_real_escape_string($db, $_POST['email']);
		$password_1 = mysqli_real_escape_string($db, $_POST['password_1']);
		$password_2 = mysqli_real_escape_string($db, $_POST['password_2']);

		// form validation: ensure that the form is correctly filled ...
		// by adding (array_push()) corresponding error unto $errors array
		if (empty($username)) {
			array_push($errors, "Username is required");
		}

		if (empty($email)) {
			array_push($errors, "Email is required");
		}

		if (empty($password_1)) {
			array_push($errors, "Password is required");
		}

		if ($password_1 != $password_2) {
			array_push($errors, "The two passwords do not match");
		}

		// first check the database to make sure
		// a user does not already exist with the same username and/or email
		$user_check_query = "SELECT * FROM jobprovider WHERE username = '$username' OR email = '$email' LIMIT 1";
		$result = mysqli_query($db, $user_check_query);
		$user = mysqli_fetch_assoc($result);

		if ($user) { // if user exists
			if ($user['username'] === $username) {
				array_push($errors, "Username already exists");
			}

			if ($user['email'] === $email) {
				array_push($errors, "email already exists");
			}
		}

		// Finally, register user if there are no errors in the form
		if (count($errors) == 0) {
			$password = md5($password_1);//encrypt the password before saving in the database

			$query = "INSERT INTO jobprovider (username, password, email, contact, link)
								VALUES('$username', '$password', '$email', $contact ,$link)";
			mysqli_query($db, $query);
			$_SESSION['username'] = $username;
			$_SESSION['email']    = $email;
			$_SESSION['email']    = $contact;
			$_SESSION['email']    = $link;
			$_SESSION['success']  = "You are now logged in";
			header('location: provider.php');
		}
}

	// LOGIN PROVIDER
	if (isset($_POST['login_provider'])) {
		$provider_username = mysqli_real_escape_string($db, $_POST['provider_username']);
		$provider_password = mysqli_real_escape_string($db, $_POST['provider_password']);

		if (empty($provider_username)) {
			array_push($errors, "Username is required");
		}

		if (empty($provider_password)) {
			array_push($errors, "Password is required");
		}

		if (count($errors) == 0) {
			$provider_password = md5($provider_password);
			$query = "SELECT * FROM jobprovider WHERE username='$provider_username' AND password='$provider_password '";
			$results = mysqli_query($db, $query);
			if (mysqli_num_rows($results) == True) {
				$_SESSION['provider_username'] = $provider_username;
				$_SESSION['provider_email'] = $provider_email;
				$_SESSION['success'] = "You are now logged in";
				header('location: provider.php');
			}else {
				array_push($errors, "Wrong username/password combination");
			}
		}
	}
?>
