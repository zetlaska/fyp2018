<?php

  $host = "localhost";
  $user = "root";
  $dbpassword = "";
  $database = "futureplan";

  $id = "";
  $username = "";
  $password = "";
  $email = "";
  $address = "";
  $contact = "";

  mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

  try{
    $connect = mysqli_connect($host, $user, $dbpassword, $database);
  }catch(Exception $ex){
    echo 'Error';
  }

  function getPosts(){
    $posts = array();
    $posts[0] = $_POST['title'];
    $posts[1] = $_POST['description'];
    $posts[2] = $_POST['salary'];
    $posts[3] = $_POST['location'];

    return $posts;
  }

  //Insert Function
	if(isset($_POST['insert'])){
		$data = getPosts();
    $insert_Query = "INSERT INTO `listing`(`title`, `description`, `salary`, `location`) VALUES ('$data[0]','$data[1]','$data[2]','$data[3]')";

		try{
			$insert_Result = mysqli_query($connect, $insert_Query);

			if($insert_Result){
				if(mysqli_affected_rows($connect) > 0){
					echo 'Data Inserted';
				}else{
					echo 'Data Not Inserted';
				}
			}
		}catch(Exception $ex){
			echo 'Error Insert'.$ex->getMessage();
		}
	}
?>
