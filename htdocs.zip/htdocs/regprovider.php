<?php include ('providerserver.php') ?>

<!doctype html>
<html>
	<head>
		<title> Register </title>
		<link rel="stylesheet" type="text/css" href="style.css">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	</head>

	<body class = "text-center">

		<div class = "spacing">
		<div class = "spacing">

		<form method = "post" action = "regprovider.php" class = "form-signin">

			<?php include ('error.php'); ?>

			<img src = "F.png" alt = "" width = "72" height = "72">

			<h1>
				Please enter your details
        (Job Provider)
			</h1>
			<div class = "spacing">
			<div class = "spacing">

			<!-- User Name -->
			<div>
				<label for = "username" class = "sr-only"> Username </label>
				<input name = "username" type = "username" id = "username" class = "form-control" placeholder = "Enter Username" value = "<?php echo $username; ?>">
			</div>

			<div class = "spacing">
			<div class = "spacing">

			<!-- Email Address -->
			<div>
				<label for = "inputEmail" class = "sr-only"> Email Address </label>
				<input name = "email" type = "email" id = "email" class = "form-control" placeholder = "example@gmail.com" value = "<?php echo $email; ?>">
			</div>

			<div class = "spacing">
			<div class = "spacing">

			<!--Password_1 -->
			<div>
				<label for = "passwordInput" class = "sr-only">
					Password
				</label>

				<input name = "password_1" type = "password" id = "password_1" class = "form-control" placeholder = "Password">
				<div class = "spacing">
				<div class = "spacing">
			</div>

			<!--Password_2 -->
			<div>
				<label for = "passwordInput" class = "sr-only">
					Confirm Password
				</label>

				<input name = "password_2" type = "password" id = "password_2" class = "form-control" placeholder = "Confirm password">
				<div class = "spacing">
				<div class = "spacing">
			</div>


			<!-- Register Button -->
			<div class = "input-group">
				<button class = "btn btn-lg btn-primary btn-block" name = "reg_provider" type = "submit">
					Register
				</button>
			</div>

			<!-- SignIn Button -->
			<div class = "input-group">
				<a href ="jobProviderLogin.php" class = "btn btn-lg btn-primary btn-block"> Login </a>
			</div>

		</form>
	</body>
</html>
