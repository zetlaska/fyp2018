<?php

	include 'server.php';
	include'functionsp.php';
	if (!isset($_SESSION['id'])) {
		$_SESSION['msg'] = "You must log in first";

		header('location: Login.php');
	}

?>

<!doctype html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta name="description" content="">
		<meta name="author" content="">
		<link rel="icon" href="../../../../favicon.ico">

		<title> Profile </title>

		<!-- Bootstrap core CSS -->
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">


		<!-- Custom styles for this template -->
		<link href="form-validation.css" rel="stylesheet">
	</head>

	<body class="bg-light">

		<div class="container">
			<div class="py-5 text-center">
				<h2> <?php echo $_SESSION['username']; ?>'s Profile</h2>
			</div>

			<div class="row">
				<div class="col-md-8 order-md-1">
					<h4 class="mb-3"> Update Personal Information </h4>

					<form class="needs-validation" action = "profile.php" method = "post">
						<div class="mb-3">
							<label for="email"> Enter Name </label>
							<input type="username" class="form-control" id="username" name = "username">
							<div class="invalid-feedback">
								Enter Name.
							</div>
						</div>

						<div class="mb-3">
							<label for="email">  Enter Password </label>
							<input type="password" class="form-control" id="password" name = "password">
							<div class="invalid-feedback">
								Enter Name.
							</div>
						</div>


						<div class="mb-3">
							<label for="email"> Email </label>
							<input type="email" class="form-control" id="email" name = "email">
							<div class="invalid-feedback">
								Please enter a valid email address.
							</div>
						</div>

						<div class="mb-3">
							<label for = "contact"> Contact Number </label>
							<input type="text" class="form-control" id="contact" name = "contact">
						</div>

						<hr class="mb-4">

						<div class="mb-3">
							<button class="btn btn-primary btn-lg btn-block" type="submit" name = "update"> Save changes </button>
						</div>

						<div class="mb-3">
							<a href = "jobSeeker.php" class ="btn btn-primary btn-lg btn-block" type="submit" name = "update"> Dashboard </a>
						</div>
					</form>
				</div>
			</div>

			<footer class="my-5 pt-5 text-muted text-center text-small">
					<p class="mb-1">
						&copy; 2017-2018 Company Name
					</p>

					<ul class="list-inline">
						<li class="list-inline-item"><a href="#">Privacy</a></li>
						<li class="list-inline-item"><a href="#">Terms</a></li>
						<li class="list-inline-item"><a href="#">Support</a></li>
					</ul>
			</footer>
		</div>
	</body>
</html>
