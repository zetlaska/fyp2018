<?php
	include 'server.php';
?>
<!doctype html>
<html>
	<head>
		<title> Admin Login </title>
		<link rel = "stylesheet" type = "text/css" href = "style.css">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

	</head>

	<body class = "text-center">
		<div id = "form">

				<div class = "spacing"/>
				<div class = "spacing"/>

			<form action = "adminlogin.php" method = "post">

				<?php include ('error.php'); ?>
				<!-- Main Logo -->
				<img class="mb-4" src="F.png" alt="" width="72" height="72">

				<!-- Main Header -->
				<h1 class="h3 mb-3 font-weight-normal"> Admin Sign In </h1>

				<div class = "spacing"/>
				<div class = "spacing"/>

				<!-- Username -->
				<label for="inputEmail" class="sr-only"> Username </label>
				<input type="text" id="username" class="form-control" placeholder="Username" name = "admin_username">

				<div class = "spacing"/>
				<div class = "spacing"/>

				<!-- Password -->
				<label for="inputPassword" class="sr-only"> Password </label>
				<input type="password" id="password" class="form-control" placeholder="Password" name = "admin_password">

				<div class = "spacing"/>
				<div class = "spacing"/>

				<!-- Sign In -->
				<button class="btn btn-lg btn-primary btn-block" type="submit" name = "login_admin"> Login </button>

				<div class = "spacing"/>
				<div class = "spacing"/>

				<!-- Job Provider Login -->
				<a href="jobProviderLogin.php" class="btn btn-lg btn-primary btn-block" type="submit"> Employer </a>

				<div class = "spacing"/>
				<div class = "spacing"/>

				<!-- Job Seeker Login -->
				<a href="Login.php" class="btn btn-lg btn-primary btn-block" type="submit"> Job Seeker </a>
				<p class="mt-5 mb-3 text-muted"><em> FuturePlan </em>&copy; 2017-2018</p>
			</form>
		</div>
	</body>
</html>
