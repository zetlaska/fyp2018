<?php
$host = "localhost";
$user = "root";
$password = "";
$database = "futureplan";

$conn=mysqli_connect($host, $user, $password, $database);

?>