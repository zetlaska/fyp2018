<?php
  include 'providerserver.php';


  $host = "localhost";
  $user = "root";
  $dbpassword = "";
  $database = "futureplan";

  $id = "";
  $username = "";
  $password = "";
  $email = "";
  $address = "";
  $contact = "";

  mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

  try{
    $connect = mysqli_connect($host, $user, $dbpassword, $database);
  }catch(Exception $ex){
    echo 'Error';
  }

  function getPosts(){

    $posts = array();
		$posts[1] = $_POST['title'];
		$posts[2] = $_POST['description'];
		$posts[3] = $_POST['salary'];
		$posts[4] = $_POST['location'];
		$posts[5] = $_SESSION['id'];
		$posts[6] = $_SESSION['username'];
    return $posts;
  } 

  //Insert Function
	if(isset($_POST['insert'])){
		$data = getPosts();
    $insert_Query = "INSERT INTO `listing`(`title`, `description`, `salary`, `location`, `provID`, `provname`) VALUES ('$data[1]','$data[2]','$data[3]', '$data[4]', '$data[5]', '$data[6]')";

		try{
			$insert_Result = mysqli_query($connect, $insert_Query);

			if($insert_Result){
				if(mysqli_affected_rows($connect) > 0){
					echo 'Data Inserted';
				}else{
					echo 'Data Not Inserted';
				}
			}
		}catch(Exception $ex){
			echo 'Error Insert'.$ex->getMessage();
		}
	}
?>
