<?php

include 'server.php';

if (!isset($_SESSION['id'])) {
    $_SESSION['msg'] = "You must log in first";
    header('location: Login.php');
}


include 'listing-view-jobseeker.php';

$host = "localhost";
$user = "root";
$password = "";
$database = "futureplan";

$conn=mysqli_connect($host, $user, $password, $database);



$headers .= 'From: DoNotReply@FuturePlan.com';


mail("$provID, $provname", "$title, $_SESSION[username]", $description, $headers);
  





?>
