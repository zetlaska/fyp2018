<?php
	session_start();

	if(isset($_POST["username"])) {
		include 'server.php';

		$id = $_POST["id"];
		$username = $_POST["username"];
		$email = $_POST["email"];
		$contact = $_POST["contact"];

		$message = "";

		if ($username == "") {

			$message = "Name must be filled!";

		} else if ($email == "") {

			$message = "Email must be filled!";
		}
		else if ($contact == "") {

			$message = "Phone number must be filled!";
		}
		else {

			$connection->query("UPDATE jobseeker SET username='".$username."', email='".$email."' WHERE id=".$id);

			$message = "Successfully updated ";

		}

		$_SESSION["message"] = $message;

		header("Location: jobseeker.php?id=".$id);
		exit();

	}

	header("admin.php");
	exit();
?>
