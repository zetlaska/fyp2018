 <!DOCTYPE html>
<html lang="en">
	<head>
  
		<title>Home Page</title>

		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
		<link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
		<link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  
		<style>

			.panel .slidedown .glyphicon, .chat .glyphicon{
				margin-right : 5px;
			}

			.panel-body{
				overflow-y : scroll;
				height     : 250px;
			}

			::-webkit-scrollbar-track{
				-webkit-box-shadow : inset 0 0 6px rgba(0,0,0,0.3);
				background-color   : #F5F5F5;
			}

			::-webkit-scrollbar{
				width            : 12px;
				background-color : #F5F5F5;
			}

			::-webkit-scrollbar-thumb{
				-webkit-box-shadow : inset 0 0 6px rgba(0,0,0,.3);
				background-color   : #555;
			}

			body{
				font        : 400 15px Lato, sans-serif;
				line-height : 1.8;
				color       : #818181;
			}
			
			h2{
				font-size      : 24px;
				text-transform : uppercase;
				color          : #303030;
				font-weight    : 600;
				margin-bottom  : 30px;
			}
		  
			.jumbotron {
				opacity     : 0.5;
				color       : black;
				padding     : 100px 25px;
				font-family : Montserrat, sans-serif;
			}
		  
			.navbar {
				background-color : black;
				margin-bottom    : 0;
				color            : #818181;
				z-index          : 9999;
				border           : 0;
				font-size        : 12px !important;
				line-height      : 1.42857143 !important;
				letter-spacing   : 4px;
				border-radius    : 0;
				font-family      : Montserrat, sans-serif;
			}
			
			.navbar li a, .navbar .navbar-brand {
			  color: #fff !important;
			}
			
			.navbar-nav li a:hover, .navbar-nav li.active a {
			  color: #f4511e !important;
			  background-color: #fff !important;
			}
		  
			.navbar-default .navbar-toggle {
			  border-color: transparent;
			  color: #fff !important;
			}
		 
			body, html { 
				background-image  : url(index.jpg) ; 
				background-repeat : no-repeat;
				background-size   : cover;
			}

			.dropdown-menu{
				background-color:black;
			}

		.email {
			padding: 15px 25px;
            position:absolute;
            bottom:0;
			text-align: center;
			cursor: pointer;
			outline: none;
			color: #fff;
		    background-color: #4CAF50;
			border: none;
			border-radius: 15px;
			box-shadow: 0 9px #999;
			}

		.email:hover {background-color: #3e8e41}

		.email:active {
		  background-color: #3e8e41;
		  box-shadow: 0 5px #666;
		  transform: translateY(4px);
 </style>
		</style>
	</head>
	
	<body id="myPage" data-spy="scroll" data-target=".navbar" data-offset="60">

		<nav class="navbar navbar-default navbar-fixed-top">
		  <div class="container">
			<div class="navbar-header">
			  <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>                        
			  </button>

			  <a class="navbar-brand" href="#myPage"><img class="mb-4" src="futureplan.png" alt="" width="72" height="72"></a>
			</div>
			<div class="collapse navbar-collapse" id="myNavbar">
				<ul class="nav navbar-nav navbar-right">
				
				<!-- Dropdown menu on Nav Bar -->
					<li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#"> LOGIN <span class="caret"></span></a>
					
						<ul class="dropdown-menu">	  
						  <li>
							<a href="" target="_blank">
								JOB SEEKERS
							</a>
						  </li>
						  
						  <li>
							<a href="" target="_blank">
								JOB PROVIDERS
							</a>
						  </li> 
						  
						  <li>
							<a href="" target="_blank">
								ADMIN
							</a>
						  </li>
						</ul>  
					
					</li>
				  
					<li>
						<a href="Payment.html" target="_blank">
							SIGN UP FOR JOB SEEKERS
						</a>
					</li>
					
					<li>
						<a href="contact.html" target="_blank">
							CONTACT
						</a>
					</li>			
				
				</ul>
			</div>
		  </div>
		</nav>

		<div class="jumbotron text-center">
			<h1>
				Future Plan
			</h1>
			
			<p>
				We specialize in finding jobs for you
			</p> 
		</div>
		<input class="email" type="button" onclick="location.href='index.php';" value="Live Chat" />

	</body>
</html>