<?php
  include 'server.php';

  if (!isset($_SESSION['provider_username'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: provider.php');
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['provider_username']);
  	header("location: jobProviderLogin.php");
  }
?>
<!doctype html>
<html>
	<head>
		<title> Job Provider Page </title>
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">

	</head>

	<body>
		<div class="content">
			<!-- notification message -->
			<?php if (isset($_SESSION['success'])) : ?>
				<div class="error success" >
					<h3>
						<?php
							echo $_SESSION['success'];
							unset($_SESSION['success']);
						?>
					</h3>
				</div>
			<?php endif ?>

			<!-- logged in user information -->
			<?php  if (isset($_SESSION['provider_username'])) : ?>
			<?php endif ?>
		</div>

		<div class="container">
			<header class="blog-header py-3">
				<!-- Top Nav Bar -->
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample08" aria-controls="navbarsExample08" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>

          <div class="collapse navbar-collapse justify-content-md-center" id="navbarsExample08">
            <ul class="navbar-nav">
-              <li class="nav-item active">
                <a class="nav-link" href="listing-view-provider.php"> View Job Listings </a>
              </li>

              <li class = "nav-item active">
                <a class="nav-link" href="profile.php"> Update Profile </a>
              </li>
            </ul>
        </div>
      </nav>
				<!-- Top Nav Bar End -->
			</header>

			<!-- Main Title Header -->
			<div class="jumbotron p-3 p-md-5 text-white rounded bg-dark">
				<div class="col-md-6 px-0">
					<h1 class="display-4 font-italic"> <?php echo $_SESSION['provider_username']; ?> </h1>
				</div>
			</div>
			<!-- Main Title Header End -->

      <?php
				$getUser = $db->query("SELECT * FROM jobprovider WHERE username ='".$_SESSION['provider_username']."'");
				$fetchUser = $getUser->fetch_assoc();
		  ?>

			<div class="row mb-2">
				<div class="col-md-6">
					<div class="card flex-md-row mb-4 shadow-sm h-md-250">
						<div class="card-body d-flex flex-column align-items-start">
							<h4>
								<strong>
									Company Information
								</strong>
							</h4>

							<p class="card-text mb-auto">
								Company Name : <strong> <?=$fetchUser["username"]?> <br/> </strong>
								Email : <strong> <?=$fetchUser["email"]?> <br/> </strong>
								Phone Number : <strong> <?=$fetchUser["contact"]?> <br/> </strong>
                Website : <strong> <?=$fetchUser["link"]?> <br/> </strong>
                ID Number : <strong> <?=$fetchUser["id"]?> <br/> </strong>
							</p>
						</div>

						<img class="card-img-right flex-auto d-none d-lg-block" data-src="holder.js/200x250?theme=thumb">
					</div>
				</div>

				<div class="col-md-6">
					<div class="card flex-md-row mb-4 shadow-sm h-md-250">
						<div class="card-body d-flex flex-column align-items-start">
							<h4>
								<strong> Job Listing Page </strong>
							</h4>

							<p class="card-text mb-auto">
								<a class="btn btn-sm btn-outline-secondary" href="listing-edit-provider.php"> Create/Edit Listing </a>
              </p>

						</div>

						<img class="card-img-right flex-auto d-none d-lg-block" data-src="holder.js/200x250?theme=thumb">
					</div>
				</div>

				<div class="col-md-6">
					<div class="card flex-md-row mb-4 shadow-sm h-md-250">
						<div class="card-body d-flex flex-column align-items-start">
							<h4>
								<strong> Live Chat Support </strong>
							</h4>

							<p class="card-text mb-auto">
								<a class="btn btn-sm btn-outline-secondary" href="../live/index.php"> Enter Chat Room </a>
							</p>

						</div>

						<img class="card-img-right flex-auto d-none d-lg-block" data-src="holder.js/200x250?theme=thumb">
					</div>
				</div>
		  </div>
		</div>

		<main role="main" class="container">
			<div class="row">

				<aside class="col-md-4 blog-sidebar">
					<div class="p-3 mb-3 bg-light rounded">
						<h4 class="font-italic">
							Social Media
						</h4>

						<p class="mb-0">
							<ol class="list-unstyled">
								<li><a href="#">GitHub</a></li>
								<li><a href="#">Twitter</a></li>
								<li><a href="#">Facebook</a></li>
							</ol>
						</p>
					</div>
				</aside>
			</div>

			<p>
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample08" aria-controls="navbarsExample08" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>

          <div class="collapse navbar-collapse justify-content-md-center" id="navbarsExample08">
            <ul class="navbar-nav">
              <li class = "nav-item active">
                  <a class="nav-link" href="jobSeeker.php?logout='1'"> Logout </a>
              </li>
            </ul>
          </div>
        </nav>
			</p>
		</main>
	</body>
</html>
