<?php
  session_start();

  if (!isset($_SESSION['admin_username'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: adminlogin.php');
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['admin_username']);
  	header("location: adminlogin.php");
  }
?>
<!doctype html>
<html>
	<head>
		<title> Admin Page </title>
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">

    <style>
      body,html{
        background-image : url(wp3.jpg);
        background-repeat : no-repeat;
        background-size : cover;
      }
    </style>

	</head>

	<body>
		<div class="content">
			<!-- notification message -->
			<?php if (isset($_SESSION['success'])) : ?>
				<div class="error success" >
					<h3>
						<?php
							echo $_SESSION['success'];
							unset($_SESSION['success']);
						?>
					</h3>
				</div>
			<?php endif ?>

			<!-- logged in user information -->
			<?php  if (isset($_SESSION['admin_username'])) : ?>
			<?php endif ?>
		</div>

		<div class="container">
			<header class="blog-header py-3">
				<script type = "text/javascript">

				</script>
				<!-- Top Nav Bar -->
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
					<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample08" aria-controls="navbarsExample08" aria-expanded="false" aria-label="Toggle navigation">
						<span class="navbar-toggler-icon"></span>
					</button>

					<div class="collapse navbar-collapse justify-content-md-center" id="navbarsExample08">
						<ul class="navbar-nav">
							<li class="nav-item active">
								<a class="nav-link" href="#"> Future Plan <span class="sr-only">(current)</span></a>
							</li>
						</ul>
				</div>
			</nav>
				<!-- Top Nav Bar End -->
			</header>

			<!-- Main Title Header -->
			<div class="jumbotron p-3 p-md-5 text-white rounded bg-dark">
				<div class="col-md-6 px-0">
					<h1 class="display-4 font-italic">Welcome Admin </h1>
				</div>
			</div>
			<!-- Main Title Header End -->

			<div class="row mb-2">
				<div class="col-md-6">
					<div class="card flex-md-row mb-4 shadow-sm h-md-250">
						<div class="card-body d-flex flex-column align-items-start">
							<h4>
								<strong>
									Admin Information
								</strong>
							</h4>

							<p class="card-text mb-auto">
								Name : <strong> <?php echo $_SESSION['admin_username']; ?>  <br/> </strong>
							</p>
						</div>

						<img class="card-img-right flex-auto d-none d-lg-block" data-src="holder.js/200x250?theme=thumb">
					</div>
				</div>


				<!-- Job Seeker Functions -->
				<div class="col-md-6">
					<div class="card flex-md-row mb-4 shadow-sm h-md-250">
						<div class="card-body d-flex flex-column align-items-start">
							<h4>
								<strong> Job Seekers Control </strong>
							</h4>

							<p class="card-text mb-auto">
								<a class="btn btn-sm btn-outline-secondary" href="priority.php"> View Job Seeker </a>
							</p>

						</div>

						<img class="card-img-right flex-auto d-none d-lg-block" data-src="holder.js/200x250?theme=thumb">
					</div>
				</div>
				<!-- Job Seeker Functions End -->


				<!-- Job Providers Functions -->
				<div class="col-md-6">
					<div class="card flex-md-row mb-4 shadow-sm h-md-250">
						<div class="card-body d-flex flex-column align-items-start">
							<h4>
								<strong> Job Providers Control </strong>
							</h4>

							<p class="card-text mb-auto">
								<a class="btn btn-sm btn-outline-secondary" href="viewprovider.php"> View Job Provider </a> <br>
              </p>
						</div>

						<img class="card-img-right flex-auto d-none d-lg-block" data-src="holder.js/200x250?theme=thumb">
					</div>
				</div>
				<!-- Job Providers Functions End -->

				<!-- Job Listing Functions -->
				<div class="col-md-6">
					<div class="card flex-md-row mb-4 shadow-sm h-md-250">
						<div class="card-body d-flex flex-column align-items-start">
							<h4>
								<strong> Job Listings Control </strong>
							</h4>

							<p class="card-text mb-auto">
								<a class="btn btn-sm btn-outline-secondary" href="listing-view-admin.php"> View Job Listings </a>
						</div>

						<img class="card-img-right flex-auto d-none d-lg-block" data-src="holder.js/200x250?theme=thumb">
					</div>
				</div>
				<!-- Job Listing Functions End -->

				<!-- Notice Board Functions -->
				<div class="col-md-6">
					<div class="card flex-md-row mb-4 shadow-sm h-md-250">
						<div class="card-body d-flex flex-column align-items-start">
							<h4>
								<strong> Live Chat Support </strong>
							</h4>

							<p class="card-text mb-auto">
                <a class="btn btn-sm btn-outline-secondary" href="../live/index.php"> Enter Chat Room </a>
							</p>

						</div>

						<img class="card-img-right flex-auto d-none d-lg-block" data-src="holder.js/200x250?theme=thumb">
					</div>
				</div>
				<!-- Notice Board Functions Ends -->

			</div>
		</div>

		<main role="main" class="container">
      <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample08" aria-controls="navbarsExample08" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse justify-content-md-center" id="navbarsExample08">
          <ul class="navbar-nav">

            <li class="nav-item">
              <a class="nav-link" href="adminlogin.php?logout='1'">
                Logout
              </a>
            </li>

          </ul>
      </div>
    </nav>
		</main>
	</body>
</html>
