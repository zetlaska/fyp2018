<?php

	$host = "localhost";
	$user = "root";
	$dbpassword = "";
	$database = "futureplan";

	$id = "";
	$username = "";
	$password = "";
	$email = "";
	$contact = "";
  $link = "";

	mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

	try{
		$connect = mysqli_connect($host, $user, $dbpassword, $database);
	}catch(Exception $ex){
		echo 'Error';
	}

	function getPosts(){
		$posts = array();
		$posts[0] = $_POST['id'];
		$posts[1] = $_POST['username'];
		$posts[2] = md5($_POST['password']);
		$posts[3] = $_POST['email'];
    $posts[4] = $_POST['contact'];
    $posts[5] = $_POST['link'];

		return $posts;
	}

	//Search Function
	if(isset($_POST['search'])){
		$data = getPosts();

		$search_Query = "SELECT * FROM jobprovider WHERE id = $data[0]";

		$search_Result = mysqli_query($connect, $search_Query);

		if($search_Result){
			if(mysqli_num_rows($search_Result)){
				while($row = mysqli_fetch_array($search_Result)){
					$id = $row['id'];
					$username = $row['username'];
					$password = $row['password'];
					$email = $row['email'];
          $contact = $row['contact'];
          $link = $row['link'];
				}
			}else{
				echo 'No data for this id';
			}
		}else{
			echo 'Result Error';
		}
	}

	//Insert Function
	if(isset($_POST['insert'])){
		$data = getPosts();
		$insert_Query = "INSERT INTO `jobprovider`(`username`, `password`, `email`, `contact`, `link`) VALUES ('$data[1]','$data[2]','$data[3]','$data[4]', '$data[5]')";

		try{
			$insert_Result = mysqli_query($connect, $insert_Query);

			if($insert_Result){
				if(mysqli_affected_rows($connect) > 0){
					echo 'Data Inserted';
				}else{
					echo 'Data Not Inserted';
				}
			}
		}catch(Exception $ex){
			echo 'Error Insert'.$ex->getMessage();
		}
	}

	//Delete Function
	if(isset($_POST['delete'])){
		$data = getPosts();
		$delete_Query = "DELETE FROM `jobprovider` WHERE `id` = '$data[0]'";

		try{
			$delete_Result = mysqli_query($connect, $delete_Query);

			if($delete_Result){
				if(mysqli_affected_rows($connect) > 0){
					echo 'Data Deleted';
				}else{
					echo 'Data Not Deleted';
				}
			}
		}catch(Exception $ex){
			echo 'Error in Deletion'.$ex->getMessage();
		}
	}

	//Update Function
	if(isset($_POST['update'])){
		$data = getPosts();
		$update_Query = "UPDATE `jobprovider` SET `username`='$data[1]',`password`= md5('$data[2]'),`email`='$data[3]', `contact` = '$data[4]', link = '$data[5]' WHERE `id` = '$data[0]'";

		try{
			$update_Result = mysqli_query($connect, $update_Query);

			if($update_Result){
				if(mysqli_affected_rows($connect) > 0){
					echo 'Data Updated';
				}else{
					echo 'Data Not Updated';
				}
			}
		}catch(Exception $ex){
			echo 'Error in Updating Data'.$ex->getMessage();
		}
	}

?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../../../favicon.ico">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">

    <title> Priority List </title>

    <!-- Bootstrap core CSS -->
    <link href="../../dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="offcanvas.css" rel="stylesheet">
  </head>

  <body class="bg-light">
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample08" aria-controls="navbarsExample08" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse justify-content-md-center" id="navbarsExample08">
        <ul class="navbar-nav">
          <li class="nav-item active">
            <a class="nav-link" href="admin.php"> Return to Dashboard </a>
          </li>
        </ul>
      </div>
    </nav>

    <main role="main" class="container">

      <div class="my-3 p-3 bg-white rounded shadow-sm">
        <h5 class="border-bottom border-gray pb-2 mb-0"> <em> Control Form </em> </h5>
        <form method = "post" action = "editjp.php">

          <div class="media text-muted pt-3">
            <img data-src="holder.js/32x32?theme=thumb&bg=007bff&fg=007bff&size=1" alt="" class="mr-2 rounded">
            <p class="media-body pb-3 mb-0 small lh-125 border-bottom border-gray">
              <strong class="d-block text-gray-dark"> Job Provider ID : </strong>
              <input type = "text" name = "id" class = "form-control" value = "<?php echo $id ?>"> <br>

              <strong class="d-block text-gray-dark"> Job Provider Username : </strong>
              <input type = "text" name = "username" class = "form-control" value = "<?php echo $username ?>"> <br>

              <strong class="d-block text-gray-dark"> Job Provider Email : </strong>
              <input type = "text" name = "email" class = "form-control" value = "<?php echo $email ?>"> <br>

							<strong class="d-block text-gray-dark"> Job Provider Contact : </strong>
              <input type = "text" name = "contact" class = "form-control" value = "<?php echo $contact ?>"> <br>

              <strong class="d-block text-gray-dark"> Job Provider Website : </strong>
              <input type = "text" name = "link" class = "form-control" value = "<?php echo $link ?>"> <br>

              <strong class="d-block text-gray-dark"> Job Provider Password : </strong>
              <input type = "password" name = "password" class = "form-control" value = "<?php echo $password ?>"> </input> <br>

              <small class="d-block text-right mt-3">
                <a class="btn btn-sm btn-outline-secondary" href = "viewprovider.php"> View Job Proivders </a>
                <input class="btn btn-sm btn-outline-secondary" type="submit" name = "search" value = "Search Job Provider">
                <input class="btn btn-sm btn-outline-secondary" type="submit" name = "insert" value = "Add Job Provider">
                <input class="btn btn-sm btn-outline-secondary" type="submit" name = "delete" value = "Delete Job Provider">
                <input class="btn btn-sm btn-outline-secondary" type="submit" name = "update" value = "Update Job Provider">
              </small>
            </p>
          </div>
        </form>
      </div>
    </main>
  </body>
</html>
