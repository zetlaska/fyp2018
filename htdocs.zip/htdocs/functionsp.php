<?php

	$host = "localhost";
	$user = "root";
	$dbpassword = "";
	$database = "futureplan";

	$id = "";
	$username = "";
	$email = "";
	$address = "";
	$contact = "";

	mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

	try{
		$connect = mysqli_connect($host, $user, $dbpassword, $database);
	}catch(Exception $ex){
		echo 'Error';
	}

	function getPosts(){
		$posts = array();
		$posts[0] = $_POST['username'];
		$posts[1] = $_POST['password'];
		$posts[2] = $_POST['email'];
		$posts[3] = $_POST['contact'];
		$posts[4] = $_SESSION['id'];

		return $posts;
	}

	//Update Function
	if(isset($_POST['update'])){
		$data = getPosts();

		

		$update_Query = "UPDATE `jobseeker` SET `username`='$data[0]',`password`= md5('$data[1]'),`email`='$data[2]',`contact`='$data[3]' WHERE `id` = '$data[4]'";


		try{
			$update_Result = mysqli_query($connect, $update_Query);

			if($update_Result){
				if(mysqli_affected_rows($connect) > 0){
					echo 'Data Updated';
				}else{
					echo 'Data Not Updated';
				}
			}
		}catch(Exception $ex){
			echo 'Error in Updating Data'.$ex->getMessage();
		}
	}

?>
