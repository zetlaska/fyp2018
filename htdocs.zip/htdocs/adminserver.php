<?php

	$db = mysqli_connect('localhost', 'root', '', 'futureplan');

  $error_login = 0;

  if(isset($_POST['admin_username'], $_POST['admin_password'])){
    $username = $_POST['admin_username'];
    $password = $_POST['admin_password'];

    if($username != null && $password != null){

      $getAdmin = "SELECT * FROM
										`admin`
									 WHERE
									 	 admin_username = '$username'
									 AND
									 	 admin_password = '$password'";
			$results = mysqli_query($db, $getAdmin);

      if(mysqli_num_rows($results) === 0){
        $_SESSION['admin_username'] = 1;
        header("Location : admin.php");
        exit();
      }else{
        $error_login = 1;
      }
    }else{
      $error_login = 1;
    }
  }
?>
